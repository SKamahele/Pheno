# /interact
# /reflect
# /state
# /qualia
# /volition
# /reset